## Welcome to the RabbitMQ JMS project, version 1.0.5

To use the RabbitMQ JMS Client, either:

* add the `rabbitmq-jms-`_version_`.jar` to your classpath
* drop it in your application's library path
* add it to your project's pom.xml:

```plain
<dependency>
	<groupId>com.rabbitmq.jms</groupId>
	<artifactId>rabbitmq-jms</artifactId>
</dependency>
```

In order to take advantage of all the function supplied by RabbitMQ JMS, a plugin needs to be
deployed on the Rabbit server as well.

See the vFabric documentation for full information.
